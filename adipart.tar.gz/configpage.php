<?php
 $UA=getenv("HTTP_USER_AGENT") or die("Error");
 if (eregi("MSIE 6", $UA))
   die ("Sorry your Browser is not supported");
 if (eregi("MSIE", $UA))
   $sucks = true;
 else
   $sucks = false;

 $dbserver="localhost";
 $dbuser="ldapphp";
 $dbpass="bcbl@2009";
 $dbname="ldappass";
 $LDAPADMIN="lfgarcia@bcbl.local";
 $LDAPADMINPASS="Sk4p0nksk4";
 $LDAPDATAFIELD="wwwhomepage";
 $LOGO="http://www.bcbl.eu/images/stories/logo_bcbl.jpg";
 $LOGO2="http://www.bcbl.eu/images/stories/basque_center.jpg";

//Debug Settings
 error_reporting(E_ALL);
 ini_set('display_errors', '1');
// End Debug Settings

 putenv('LDAPTLS_REQCERT=never') or die('Failed to setup the env');

// NON SSL

 $LDAPHOST='pfc.bcbl.local';
 $ldap = ldap_connect($LDAPHOST) or die ('<p class="message">Error al conectar a LDAP');

// SSL

/*
 $LDAPHOST='ldaps://pfc.bcbl.local';
 $LDAPPORT=636;
 $ldap = ldap_connect($LDAPHOST, $LDAPPORT) or die ('<p class="message">Error al conectar a LDAP');
*/

 ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
 ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

function headerSet() {

print <<<HEAD
<div style="text-align:center;margin-left:auto;margin-right:auto;display:block">
<img style="margin-left:auto;margin-right:auto;display:block" src="http://www.bcbl.eu/images/stories/logo_bcbl.jpg">
<img style="margin-left:auto;margin-right:auto;display:block" src="http://www.bcbl.eu/images/stories/basque_center.jpg">
</div>
HEAD;


}

function setCss() {


print <<<CSS
<html>

<style>
p.message{
  font: 16px;
  font-family:Arial,Helvetica,sans-serif;
  color: red;
  text-align: center;
}


p.minitext {

  font: 9px Arial,Helvetica,sans-serif;
  font-family: Arial,Helvetica,sans-serif;
  color: #707070;
  text-align: center;

}
</style>
CSS;

}

function centerField() {

global $sucks;

  if ($sucks)
    print '<div style="text-align:center">';
  else
    print '<div >';

}

function putExtra(){

global $sucks;

  if ($sucks)
    print "class=\"textInput\" onmouseover=\"className='textInput_win'\"  onmouseout=\"className='textInput'\" ";
  else
    print "class=\"textInput\"";

}



function genPassword($pattern,$chardef = array(
    'v' => 'aeiouy',
    'c' => 'bcdfghjklmnpqrstvwxz',
    'V' => 'AEIOUY',
    'C' => 'BCDFGHIJKLMNPQRSTVWXZ',
    'w' => 'aeiouyAEIOUY',
    'd' => 'bcdfghjklmnpqrstvwxzBCDFGHIJKLMNPQRSTVWXZ',
    'a' => 'abcdefghijklmnopqrstuvwxyz',
    'A' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    'b' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
    '#' => '!@#$%^&*(){}[]-=\_+|<>?,./',
    '0' => '1234567890',
    'y' => 'abcdefghijklmnopqrstuvwxyz1234567890',
    'Y' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890',
    'x' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890',
    'z' => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*(){}[]-=\_+|<>?,./1234567890'
   ))
{
    $output = "";
    $chardef_keys = array_keys($chardef);
    for($i=0;$i<strlen($pattern);$i++) {
        if(in_array(substr($pattern,$i,1),$chardef_keys)) {
            $output .= substr($chardef[substr($pattern,$i,1)],rand(0,strlen($chardef[substr($pattern,$i,1)])-1),1);
        }
    }
    return $output;
}


?>
