
<?php
require_once('configpage.php');
/*$UA=getenv("HTTP_USER_AGENT");
if (eregi("MSIE 6", $UA))
  die ("Sorry your Browser is not supported");
if (eregi("MSIE", $UA))
  $sucks = true;
else 
  $sucks = false;
*/
if (@$_SERVER["HTTPS"]) {
    $_SESSION["secure"] = true;
    print "HTTPS";
  } 
  else {
    $_SESSION["secure"] = false;
    print "HTTP";
  }

function footer() {
 print <<<MSG

<p class=minitext> BCBL Web Tools 2010</p>

MSG;

}

?>


<html>


<head>
<link rel="stylesheet" href="jquery.notifyBar.css" type="text/css" media="screen" />

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript" charset="utf-8">
</script>

<script type="text/javascript" src="jquery.notifyBar.js"></script>

<style type="text/css">

fieldset {
  width: 430px;
  position: relative;
  margin-left:auto;
  margin-right:auto;
  background: #F0F0F0;
  border-color: #c0c0c0;
}

p.sansserif{
  font: 16px;
  font-family:Arial,Helvetica,sans-serif;

}

.textInput,textarea {
  width: 250px;
  font:bold 16px/16px Arial,Helvetica,sans-serif;
  font-family: Arial,Helvetica,sans-serif;
  background-color: #FFFFFF;
  border: 1px solid #000;
  border-color: #c0c0c0;
}

.textInput:hover {
    border: 1px solid #000;
    background: #BDEDFF;
}

.textInput_win {
    width: 250px;
    font:bold 16px/16px Arial,Helvetica,sans-serif;
    font-family: Arial,Helvetica,sans-serif;
    background-color: #FFFFFF;
    border: 1px solid #000;
    background: #BDEDFF;
}

.inputHighlighted {
  width: 250px;
  font:bold 16px/16px Arial,Helvetica,sans-serif;
  font-family: Arial,Helvetica,sans-serif;
  background-color: #FDD017;
  color: #000;
  border: 1px solid #000;
}


 .recaptchatable .recaptcha_image_cell, #recaptcha_table {
   background-color:#00A1E5 !important; //reCaptcha widget background color
 }
 
 #recaptcha_table {
   border-color: #033D55 !important; //reCaptcha widget border color
 }
 
 #recaptcha_response_field {
   border-color: #033D55 !important; //Text input field border color
   background-color: #FFF !important; //Text input field background color
 }

p.minitext {

  font: 9px Arial,Helvetica,sans-serif;
  font-family: Arial,Helvetica,sans-serif;
  color: #707070;
  text-align:center;

}

.custom {
  font-size:20px;
  font-family: "Times New Roman", Times, serif;
  text-transform:uppercase;
  background:#fff url(jq-test-pattern.gif) repeat-x top center;
}


</style>

<script>
var RecaptchaOptions = {
   theme : 'clean'
};

</script>

<script language="javascript">

//Suexplorador no soporta java o lo tiene deshabilitado; esta pagina necesita javascript para funcionar correctamente<!--
//Copyright © McAnam.com

function mail(elem){
    var texto = elem.value;
    var mailres = true;            
    var cadena = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ1234567890@._-";
    
    var arroba = texto.indexOf("@",0);
    if ((texto.lastIndexOf("@")) != arroba) arroba = -1;
    
    var punto = texto.lastIndexOf(".");
                
     for (var contador = 0 ; contador < texto.length ; contador++){
        if (cadena.indexOf(texto.substr(contador, 1),0) == -1){
            mailres = false;
            break;
     }
    }

    if ((arroba > 1) && (arroba + 1 < punto) && (punto + 1 < (texto.length)) && (mailres == true) && (texto.indexOf("..",0) == -1)) {
      domain=texto.substr(arroba,texto.length);
      if (domain=="@bcbl.eu"){
        $.notifyBar({ cls: "custom", html: randomErrors()+", your email can't be @bcbl.eu, please try again.", delay: 5000 });
        badField(elem);
        //alert ("The email can't be "+domain);
        mailres=false;
      } 
      else 
      mailres=true;
    }
    else {
     mailres = false;
     $.notifyBar({ cls: "error", html: randomErrors()+", Incorrect email format!", delay: 3500 });
     badField(elem);

    }      
    return mailres;
}

function badField(elem) {
  <?php global $sucks;
  if (!($sucks))
    print "elem.setAttribute(\"class\", \"inputHighlighted\");";
  else 
     print "elem.setAttribute(\"className\", \"inputHighlighted\");";
  ?>
  elem.setAttribute("aria-invalid","true");
}


function isNotEmpty(elem) {
    var str = elem.value;
    var re = /.+/;
    if(!str.match(re)) {
        $.notifyBar({ cls: "error", html: randomErrors()+", Information on "+elem.name+" field is missing.", delay: 3500 });
        badField(elem);
        return false;
    } else {
      if (elem.name == "username")
        if  (isValidUser(elem))
          return true;
        else
          return false;
      else
        return true;
    }
}

function isValidUser(user) {

  var uname = user.value;
  var regexpstr = /(^[a-z.]+$)/;
  if (uname.search(regexpstr) == -1) {
    $.notifyBar({ cls: "error", html: randomErrors()+", Information for "+user.name+" is incorrect, please review ", delay:4000 });
    badField(user);
    return false;
  }
  else {
  // alert ("machea");
   uname = uname.replace(/[.]+/g,'');
   document.data.username.value=uname;
   return true;
  }
}



function resetForms(elem) {

  elem.setAttribute("class", "textInput");

}

function checkmails(text1, text2) {

  if (text1.value==text2.value) {
    return true;
  }
  else {
    $.notifyBar({ cls: "error", html: randomErrors()+", Email does not match!", delay: 3500 });
    badField(text1);
    badField(text2);
    //alert ("Email does not match");
    return false;
  }
}

function checkForm() {

//  alert(document.data.email.value);
//  alert(document.data.user_name.value);
//  alert(document.data.password.value);

  document.data.boton.disabled=true;
  resetForms(data.email);  
  resetForms(data.confirmemail);  
  resetForms(data.username);  
  resetForms(data.password);  
  if (mail(document.data.email) && mail(document.data.confirmemail) && isNotEmpty(document.data.username) && isNotEmpty(document.data.password) && checkmails(data.email, data.confirmemail) ) {
    //alert(document.data.email.value);
    return true;
  }
  else {
//    alert("Missing Data, please fill out the form");
    return false;
  }

}

function randomErrors (){

  var phrasenumber = Math.floor(Math.random()*10);
  switch (phrasenumber) {
    case 0: return "Opps!"; break;
    case 1: return "Error!"; break;
    case 2: return "Ouch!"; break;
    case 3: return "Mmmm!"; break;
    case 4: return "Damn!"; break;
    case 5: return "WTF!"; break;
    case 6: return "OMG!"; break;
    case 7: return "Doh!"; break;
    case 8: return "Shhh!"; break;
    case 9: return "Ostiaaa!"; break;
    case 10: return "Argh!"; break;
    default: return "Me cago en..."; break;
  }

}

</script>


</head>

<?php
headerSet()
?>
<br>
<form name="data" action="passreset.php" method="post" onSubmit="return checkForm()">

<?php 
centerField(); 
?>
<fieldset class="fieldset">
 <table>
  <tr>
    <td align=right><p class="sansserif">Username:</td>
    <td> <input <?php putExtra(); ?> type="text" name="username" onFocus="javascript:data.boton.disabled=false;"></td>
  </tr>
  <tr>
    <td align=right><p class="sansserif">Password: </td>
    <td><input <?php putExtra(); ?> type="password" name="password" onFocus="javascript:data.boton.disabled=false;"></td>
  </tr>
  <tr>
    <td align=right><p class="sansserif">Personal Email:</td>
    <td><input <?php putExtra(); ?> type="text" name="email" onFocus="javascript:data.boton.disabled=false;"></td>
  </tr>
  <tr>
    <td align=right><p class="sansserif">Confirm Email: </td>
    <td><input <?php putExtra(); ?> type="text" name="confirmemail" onFocus="javascript:data.boton.disabled=false;"></td>
  </tr>
</table>
<p class="minitext"> Please fill out the following field for human verification </p>
<?php
      require_once('recaptchalib.php');
      $publickey = "6LclB7wSAAAAAESgWAGrQMwfsq8bLP0l5DTPfOqq"; // you got this from the signup page
      echo recaptcha_get_html($publickey)."<br>";
    ?>

<input style="float:right" type="submit" value="Submit" name="boton"> <br>

</form >
</fieldset>
</div>
<?php
footer();
?>
</html>

